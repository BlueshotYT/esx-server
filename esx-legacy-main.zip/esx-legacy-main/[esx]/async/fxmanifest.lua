fx_version 'cerulean'
game 'gta5'

description 'Async'

shared_script 'async.lua'
