Locales['es'] = {
  ['skin_menu'] = 'Menú Aspecto',
  ['use_rotate_view'] = 'Utiliza ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ y ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ para rotar la vista.',
  ['skin'] = 'cambiar aspecto',
  ['saveskin'] = 'guardar aspecto en un archivo',
}
