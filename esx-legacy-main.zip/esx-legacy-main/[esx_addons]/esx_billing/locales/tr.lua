Locales['tr'] = {
	['invoices'] = 'faturalar',
	['invoices_item'] = '%s TL',
	['received_invoice'] = '~r~Yeni~s~ bir fatura aldınız',
	['paid_invoice'] = '~r~%s~s~ Liralık faturanız ödendi',
	['no_invoices'] = 'şuan ödenmeyi bekleyen bir faturanız yok',
	['received_payment'] = 'faturadan ~r~%s~s~ Liralık para kazandınız',
	['player_not_online'] = 'oyuncu aktif değil',
	['no_money'] = 'bu faturayi odemek icin yeterli paran yok',
	['target_no_money'] = 'oyuncunun faturayı ödeyecek miktarda parası yok',
	['keymap_showbills'] = 'faturalar menüsünü aç',
}
