Locales['hu'] = {
  ['invoices'] = 'Számlák',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'Kaptál egy számlát',
  ['paid_invoice'] = 'Befizettél egy számlát ( ~r~$%s~s~ )',
  ['no_invoices'] = 'Nincsen számlád amit kifizethetnél',
  ['received_payment'] = 'Fizetést kaptál: ~r~$%s~s~',
  ['player_not_online'] = 'A játékos nem elérhető',
  ['no_money'] = 'Nincsen elég pénzed, hogy kifizesd ezt a számlát',
  ['target_no_money'] = 'A játékosnak nincsen annyi pénze, hogy befizesse a számlát',
  ['keymap_showbills'] = 'Számlák megnézése',
}
