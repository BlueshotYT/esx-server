Locales['es'] = {
  ['activated']   = 'Activado',
  ['deactivated'] = 'Desactivado',
}
