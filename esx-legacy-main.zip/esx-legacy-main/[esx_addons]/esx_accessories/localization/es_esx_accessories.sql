USE `es_extended`;

INSERT INTO `datastore` (name, label, shared) VALUES
    ('user_ears', 'Accesorio de oreja', 0),
    ('user_glasses', 'Gafas', 0),
    ('user_helmet', 'Casco', 0),
    ('user_mask', 'Máscara', 0)
;
