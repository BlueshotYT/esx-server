Locales['hu'] = {
  ['valid_purchase'] = 'Biztosan kifizeted?',
  ['yes'] = 'Igen',
  ['no'] = 'Nem',
  ['not_enough_money'] = 'Nincsen elég pénzed',
  ['press_access'] = 'Nyomj ~INPUT_CONTEXT~ hogy megnyisd a ~y~Fodrászatot~s~.',
  ['barber_blip'] = 'Fodrászat',
  ['you_paid'] = 'Fizettél ~g~$%s~s~',
}
