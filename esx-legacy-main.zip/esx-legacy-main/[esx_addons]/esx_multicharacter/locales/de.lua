Locales['de'] = {
	['male'] = "Männlich",
	['female'] = "Weiblich",
	['delete_label'] = "Lösche %s %s?",
	['select_char'] = "Charakter auswählen",
	['create_char'] = "Neuen Charakter erstellen",
	['char_play'] = "Diesen Charakter spielen",
	['char_delete'] = "Diesen Charakter löschen",
	['cancel'] = "Abbrechen",
	['confirm'] = "Bestätigen",
}
